package com.zangdaru.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.InputStream;
import java.util.Locale;

final class Ui {
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    static final class Pal {
        final int bg, primary, soft, text, g1, g2, g3, edge;
        Pal(int bg, int primary, int soft, int text, int g1, int g2, int g3, int edge) {
            this.bg = bg; this.primary = primary; this.soft = soft; this.text = text;
            this.g1 = g1; this.g2 = g2; this.g3 = g3; this.edge = edge;
        }
    }

    // صورتی، نعنایی، سفید، آبی، سبز
    static final String[] THEME_NAMES = {"صورتی", "نعنایی", "سفید", "آبی", "سبز"};
    static final int[] DOTS = {0xFFF48FB1, 0xFF80E0C0, 0xFFFFFFFF, 0xFF64B5F6, 0xFF81C784};
    static final Pal[] PALS = {
        new Pal(0xFFFFF1F6, 0xFFE0558A, 0xFFFFD9E6, 0xFF4A1F33, 0xFFFFC7DE, 0xFFFFEBD6, 0xFFD2C0FF, 0xCCFFFFFF),
        new Pal(0xFFEEFBF5, 0xFF2FAE8A, 0xFFC9F1E2, 0xFF174536, 0xFFB4F0D8, 0xFFE4FAF1, 0xFFA9E4F5, 0xCCFFFFFF),
        new Pal(0xFFFFFFFF, 0xFF607D8B, 0xFFECEFF1, 0xFF263238, 0xFFFFFFFF, 0xFFE9EEF5, 0xFFCFDDF3, 0x99607D8B),
        new Pal(0xFFEEF6FF, 0xFF2878C8, 0xFFCFE4FA, 0xFF11365E, 0xFFBBDBFF, 0xFFE6F2FF, 0xFFC9CCFF, 0xCCFFFFFF),
        new Pal(0xFFF1F9EC, 0xFF3E9A43, 0xFFD3EDCB, 0xFF1B4B1E, 0xFFC6EDB8, 0xFFEDF9E6, 0xFFB8EBD6, 0xCCFFFFFF)
    };

    static Pal pal(Context c) { return PALS[Store.theme(c)]; }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static boolean isLight(int col) {
        double l = (0.299 * Color.red(col) + 0.587 * Color.green(col) + 0.114 * Color.blue(col)) / 255.0;
        return l > 0.72;
    }

    static int blend(int a, int b, float t) {
        int r = Math.round(Color.red(a) * (1 - t) + Color.red(b) * t);
        int g = Math.round(Color.green(a) * (1 - t) + Color.green(b) * t);
        int bl = Math.round(Color.blue(a) * (1 - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }

    /** g from 0 to 100: gives lo at 0, mid at 50 and hi at 100. */
    static int mix3(int g, int lo, int mid, int hi) {
        if (g <= 50) return lo + (mid - lo) * g / 50;
        return mid + (hi - mid) * (g - 50) / 50;
    }

    static int withAlpha(int rgb, int alpha) { return (rgb & 0x00FFFFFF) | (alpha << 24); }

    /** Frosted-glass surface: translucent fill that is lighter at the top, with a thin bright edge. */
    static GradientDrawable box(Context c, int color, float radiusDp) {
        int top, bottom;
        if (Color.alpha(color) == 255) {
            if (isLight(color)) {
                int f = blend(color, Color.WHITE, 0.55f);
                int g = Store.glass(c);
                top = withAlpha(f, mix3(g, 0x22, 0xB8, 0xFF));
                bottom = withAlpha(f, mix3(g, 0x12, 0x6E, 0xFA));
            } else {
                int g = Store.glass(c);
                top = withAlpha(blend(color, Color.WHITE, 0.18f), mix3(g, 0x99, 0xEC, 0xFF));
                bottom = withAlpha(color, mix3(g, 0x88, 0xD6, 0xFF));
            }
        } else {
            top = color;
            bottom = color;
        }
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1.4f)), pal(c).edge);
        return g;
    }

    static int darker(int c, float f) {
        return Color.argb(Color.alpha(c), Math.round(Color.red(c) * f), Math.round(Color.green(c) * f), Math.round(Color.blue(c) * f));
    }

    /**
     * Raised 3D plate: a thick darker side underneath, a glossy gradient face with a bright bevel
     * rim and a light reflection on the upper half. When pressed the face sinks into the side.
     */
    static Drawable plate3d(Context c, int color, float radiusDp, float depthDp) {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, plateLayers(c, color, radiusDp, depthDp, true));
        sl.addState(new int[]{}, plateLayers(c, color, radiusDp, depthDp, false));
        return sl;
    }

    private static LayerDrawable plateLayers(Context c, int color, float radiusDp, float depthDp, boolean pressed) {
        float r = dp(c, radiusDp);
        int depth = dp(c, depthDp);
        int rgb = color | 0xFF000000;

        GradientDrawable edge = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{darker(rgb, 0.66f), darker(rgb, 0.46f)});
        edge.setCornerRadius(r);
        int plateAlpha = mix3(Store.glass(c), 0xB0, 0xFF, 0xFF);   // very clear glass makes the plates glassy too
        edge.setAlpha(plateAlpha);

        GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{blend(rgb, Color.WHITE, 0.30f), rgb, darker(rgb, 0.90f)});
        face.setCornerRadius(r);
        face.setAlpha(plateAlpha);
        face.setStroke(Math.max(1, dp(c, 1.3f)), withAlpha(blend(rgb, Color.WHITE, 0.70f), 0xC0));

        GradientDrawable shine = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x78FFFFFF, 0x06FFFFFF});
        shine.setCornerRadii(new float[]{r, r, r, r, r * 0.55f, r * 0.55f, r * 0.55f, r * 0.55f});
        Drawable gloss = new InsetDrawable(shine, 0.03f, 0.06f, 0.03f, 0.50f);

        LayerDrawable ld = new LayerDrawable(new Drawable[]{edge, face, gloss});
        int sink = pressed ? Math.round(depth * 0.7f) : 0;
        ld.setLayerInset(0, 0, 0, 0, 0);
        ld.setLayerInset(1, 0, sink, 0, depth - sink);
        ld.setLayerInset(2, 0, sink, 0, depth - sink);
        return ld;
    }

    /** Small "press" animation: the button shrinks slightly while the finger is down. */
    static void pressFx(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            }
            return false;
        });
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static Button button(Context c, String s, int bg, int fg) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setBackground(plate3d(c, bg, 18, 6));
        b.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14) + dp(c, 6));
        b.setElevation(dp(c, 3));
        if (!isLight(bg)) b.setShadowLayer(3, 0, 2, 0x66000000);
        pressFx(b);
        return b;
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(c, topDp);
        return p;
    }

    /** Sets content, forces right-to-left layout and tints the status bar. */
    static void apply(Activity a, View content) {
        Pal p = pal(a);
        content.setBackground(null);                                  // let the glass backdrop show through
        a.setContentView(content);
        a.getWindow().setBackgroundDrawable(new GlassBg(p.g1, p.g2, p.g3, p.primary, Store.bgStyle(a), a.getResources().getDisplayMetrics().density));
        View dv = a.getWindow().getDecorView();
        dv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        a.getWindow().setStatusBarColor(Color.TRANSPARENT);
        a.getWindow().setNavigationBarColor(Color.TRANSPARENT);
        int f = dv.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        dv.setSystemUiVisibility(f);
    }

    static String hm(int h, int m) { return String.format(Locale.US, "%02d:%02d", h, m); }

    static String fa(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('\u06F0' + (ch - '0')) : ch);
        return sb.toString();
    }

    static Bitmap decodeUri(Context c, Uri uri, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int s = 1;
            while (o.outWidth / (s * 2) >= max || o.outHeight / (s * 2) >= max) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            in = c.getContentResolver().openInputStream(uri);
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            int rot = 0;
            in = c.getContentResolver().openInputStream(uri);
            try {
                ExifInterface ex = new ExifInterface(in);
                int ori = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
                if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
            } catch (Exception e) { /* no exif */ } finally { in.close(); }
            if (b != null && rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    static Bitmap decodeFile(String path, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            int s = 1;
            while (o.outWidth / (s * 2) >= max || o.outHeight / (s * 2) >= max) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            return BitmapFactory.decodeFile(path, o2);
        } catch (Exception e) {
            return null;
        }
    }

    /** Title bar with a back arrow (arrow points right because the layout is right-to-left). */
    static LinearLayout topBar(final Activity a, String title) {
        Pal p = pal(a);
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setBackground(plate3d(a, darker(p.primary, 0.88f), 22, 7));
        bar.setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10) + dp(a, 7));
        bar.setElevation(dp(a, 4));
        TextView back = text(a, "→", 30, Color.WHITE, true);
        back.setPadding(dp(a, 8), 0, dp(a, 16), 0);
        back.setOnClickListener(v -> a.finish());
        bar.addView(back);
        TextView tt = text(a, title, 22, Color.WHITE, true);
        tt.setShadowLayer(5, 0, 2, 0x88000000);
        bar.addView(tt);
        return bar;
    }

    /** Shows a dialog with right-to-left layout. */
    static AlertDialog show(AlertDialog.Builder b) {
        AlertDialog d = b.show();
        d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        try {
            Context c = d.getContext();
            d.getWindow().setBackgroundDrawable(new android.graphics.drawable.InsetDrawable(
                    box(c, Color.WHITE, 24), dp(c, 12)));
            if (Build.VERSION.SDK_INT >= 31) d.getWindow().setBackgroundBlurRadius(60);
        } catch (Exception e) { /* keep the normal dialog */ }
        return d;
    }

    static final int WHITE = Color.WHITE;
}
