package com.zangdaru.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends BaseActivity {
    private Ui.Pal p;

    // ---- live countdown ----
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            tick();
            handler.postDelayed(this, 1000);
        }
    };
    private LinearLayout cdBox;
    private TextView cdTitle, cdDigits, cdSub;
    private Countdown.Next cur;
    private long lastCompute;
    private int shownState = -1;
    private final ArrayList<TextView> medTimers = new ArrayList<>();
    private final ArrayList<Med> medRefs = new ArrayList<>();
    private final ArrayList<Long> medTargets = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ArrayList<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            need.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!CalSync.has(this)) {
            need.add("android.permission.READ_CALENDAR");
            need.add("android.permission.WRITE_CALENDAR");
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1);
        new Thread(() -> CalSync.heal(this)).start();
        Alarms.scheduleAll(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
        handler.removeCallbacks(ticker);
        handler.postDelayed(ticker, 1000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rc, perms, res);
        new Thread(() -> CalSync.heal(this)).start();
        build();
    }

    private void build() {
        p = Ui.pal(this);
        medTimers.clear();
        medRefs.clear();
        medTargets.clear();
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);
        sv.addView(col);

        // ---- header ----
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setBackground(Ui.plate3d(this, Ui.darker(p.primary, 0.88f), 26, 8));
        head.setPadding(pad, pad, pad, pad + Ui.dp(this, 8));
        head.setElevation(Ui.dp(this, 5));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        head.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72)));
        LinearLayout tc = new LinearLayout(this);
        tc.setOrientation(LinearLayout.VERTICAL);
        tc.setPadding(pad, 0, pad, 0);
        TextView appTitle = Ui.text(this, "زنگ دارو", 32, Color.WHITE, true);
        appTitle.setShadowLayer(8, 0, 3, 0x99000000);
        tc.addView(appTitle);
        tc.addView(Ui.text(this, "یادآور مصرف دارو و وقت پزشک", 16, Color.WHITE, false));
        head.addView(tc);
        col.addView(head, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        // ---- notifications warning ----
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.areNotificationsEnabled()) {
            LinearLayout warn = new LinearLayout(this);
            warn.setOrientation(LinearLayout.VERTICAL);
            warn.setBackground(Ui.box(this, 0xFFFFE0B2, 16));
            warn.setPadding(pad, pad, pad, pad);
            warn.addView(Ui.text(this, "⚠️ اعلان‌های برنامه خاموش است و زنگ دارو به‌درستی کار نمی‌کند.", 17, 0xFF5D4037, true));
            TextView fix = Ui.button(this, "روشن کردن اعلان‌ها", 0xFFFB8C00, Color.WHITE);
            fix.setOnClickListener(v -> openNotificationSettings());
            warn.addView(fix, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
            col.addView(warn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        }

        // ---- live countdown to the next alarm ----
        cdBox = new LinearLayout(this);
        cdBox.setOrientation(LinearLayout.VERTICAL);
        cdBox.setGravity(Gravity.CENTER_HORIZONTAL);
        cdBox.setPadding(pad, pad, pad, pad);
        cdTitle = Ui.text(this, "", 16, p.text, true);
        cdTitle.setGravity(Gravity.CENTER);
        cdDigits = Ui.text(this, "--:--:--", 50, p.primary, true);
        cdDigits.setTextDirection(View.TEXT_DIRECTION_LTR);
        cdDigits.setGravity(Gravity.CENTER);
        cdDigits.setShadowLayer(6, 0, 3, 0x33000000);
        cdSub = Ui.text(this, "", 17, p.text, false);
        cdSub.setGravity(Gravity.CENTER);
        cdBox.addView(cdTitle, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        cdBox.addView(cdDigits, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        cdBox.addView(cdSub, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        col.addView(cdBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 14));

        // ---- four steps, each with its own color and symbol ----
        col.addView(step("💊", "افزودن یادآوری دارو", "داروی جدید با عکس و ساعت‌های مصرف",
                0xFFD81B60, EditActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 16));
        col.addView(step("🩺", "افزودن یادآور نوبت پزشک", "نام پزشک، روز و ساعت مراجعه",
                0xFFEF6C00, ApptEditActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(step("📅", "مشاهده تقویم نوبت و دارو", "تقویم شمسی سال با روزهای دارو و پزشک",
                0xFF1E88E5, CalendarActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(step("⚙️", "مشاهده تنظیمات برنامه", "رنگ برنامه، راهنما، درباره‌ی برنامه",
                0xFF2E7D32, SettingsActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));

        // ---- next doctor visit ----
        long now = System.currentTimeMillis();
        Appt next = null;
        for (Appt a : Store.allAppts(this)) { if (a.millis() > now) { next = a; break; } }
        if (next != null) {
            LinearLayout nc = new LinearLayout(this);
            nc.setOrientation(LinearLayout.VERTICAL);
            nc.setBackground(Ui.box(this, 0xFFFFE0B2, 20));
            nc.setPadding(pad, pad, pad, pad);
            nc.addView(Ui.text(this, "🩺 وقت بعدی پزشک", 16, 0xFF5D4037, true));
            nc.addView(Ui.text(this, next.doctor, 22, 0xFF3E2723, true));
            nc.addView(Ui.text(this, Jalali.fmtFull(next.dateKey) + " - ساعت " + next.timeText(), 17, 0xFF3E2723, false));
            nc.setOnClickListener(v -> startActivity(new Intent(this, AppointmentsActivity.class)));
            col.addView(nc, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        }

        // ---- medicines ----
        col.addView(Ui.text(this, "💊 داروهای من", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 20));
        ArrayList<Med> meds = Store.all(this);
        if (meds.isEmpty()) {
            TextView empty = Ui.text(this, "هنوز دارویی اضافه نکرده‌اید.\nروی «افزودن یادآوری دارو» بزنید.", 18, p.text, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(pad, Ui.dp(this, 24), pad, Ui.dp(this, 24));
            col.addView(empty, Ui.lp(this, Ui.MATCH, Ui.WRAP, 4));
        }
        for (Med m : meds) col.addView(card(m), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));

        Ui.apply(this, sv);
        shownState = -1;
        tick();
    }

    /** One big colored step button: round white badge with a symbol, title, short hint, arrow. */
    private View step(String emoji, String title, String sub, int color, final Class<?> target) {
        int pad = Ui.dp(this, 14);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.plate3d(this, color, 24, 8));
        row.setPadding(pad, pad, pad, pad + Ui.dp(this, 8));
        row.setMinimumHeight(Ui.dp(this, 98));
        row.setElevation(Ui.dp(this, 5));
        Ui.pressFx(row);

        GradientDrawable circle = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFFFFFFFF, 0xFFDDE1E8});
        circle.setShape(GradientDrawable.OVAL);
        circle.setStroke(Ui.dp(this, 2), 0xFFFFFFFF);
        TextView icon = Ui.text(this, emoji, 30, color, false);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(circle);
        icon.setElevation(Ui.dp(this, 4));
        row.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 62), Ui.dp(this, 62)));

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(pad, 0, pad, 0);
        TextView ttl = Ui.text(this, title, 21, Color.WHITE, true);
        ttl.setShadowLayer(4, 0, 2, 0x77000000);
        tx.addView(ttl);
        tx.addView(Ui.text(this, sub, 14, 0xFFFFFFFF, false));
        row.addView(tx, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));

        row.addView(Ui.text(this, "‹", 34, Color.WHITE, true));
        row.setOnClickListener(v -> startActivity(new Intent(this, target)));
        return row;
    }

    /** Runs every second while the home screen is visible. */
    private void tick() {
        if (cdTitle == null) return;
        long now = System.currentTimeMillis();
        if (cur == null || cur.ringing || now - lastCompute >= 3000 || (cur.target > 0 && now >= cur.target)) {
            cur = Countdown.compute(this);
            lastCompute = now;
        }
        int state = cur.ringing ? 1 : 0;
        if (state != shownState) {
            shownState = state;
            cdBox.setBackground(Ui.box(this, state == 1 ? 0xFFFFCDD2 : p.soft, 24));
            cdDigits.setTextColor(state == 1 ? 0xFFC62828 : p.primary);
        }
        if (cur.ringing) {
            cdTitle.setText("⏰ زنگ در حال نواخته شدن");
            cdDigits.setText(Countdown.hms(0));
            cdSub.setText(cur.medName + " — «مصرف کردم» را بزنید");
        } else if (cur.target < 0) {
            cdTitle.setText("⏳ زنگی در پیش نیست");
            cdDigits.setText("--:--:--");
            cdSub.setText("یک دارو اضافه کنید و روزهایش را از تقویم بزنید");
        } else {
            cdTitle.setText("⏳ زمان باقی‌مانده تا زنگ بعدی");
            cdDigits.setText(Countdown.hms(cur.target - now));
            cdSub.setText(cur.medName + " — ساعت " + Jalali.fa(cur.time));
        }
        for (int i = 0; i < medTimers.size(); i++) {
            Med m = medRefs.get(i);
            long t = medTargets.get(i);
            if (t <= now) {
                t = Countdown.nextForMed(this, m, now);
                medTargets.set(i, t);
            }
            TextView tv = medTimers.get(i);
            if (cur.ringing && cur.medId == m.id) tv.setText("⏰ زنگ می‌خورد");
            else if (t < 0) tv.setText("دوره‌ی مصرف تمام شد");
            else tv.setText("⏳ " + Countdown.hms(t - now));
        }
    }

    private View card(final Med m) {
        int pad = Ui.dp(this, 12);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.box(this, p.soft, 20));
        row.setPadding(pad, pad, pad, pad);

        int size = Ui.dp(this, 76);
        if (m.hasPhoto()) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(Ui.decodeFile(m.photo, 300));
            row.addView(iv, new LinearLayout.LayoutParams(size, size));
        } else {
            TextView pill = Ui.text(this, "💊", 36, p.text, false);
            pill.setGravity(Gravity.CENTER);
            pill.setBackground(Ui.box(this, Color.WHITE, 16));
            row.addView(pill, new LinearLayout.LayoutParams(size, size));
        }
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(pad, 0, pad, 0);
        info.addView(Ui.text(this, m.name, 22, p.text, true));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < m.times.size(); i++) {
            if (i > 0) sb.append(" ، ");
            sb.append(Jalali.fa(m.times.get(i)));
        }
        info.addView(Ui.text(this, "🕐 " + sb, 18, p.text, false));
        TextView cdv = Ui.text(this, "", 16, p.primary, true);
        cdv.setTextDirection(View.TEXT_DIRECTION_LTR);
        info.addView(cdv);
        medTimers.add(cdv);
        medRefs.add(m);
        medTargets.add(0L);
        row.addView(info, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        row.setOnClickListener(v -> {
            Intent i = new Intent(this, EditActivity.class);
            i.putExtra("id", m.id);
            startActivity(i);
        });
        return row;
    }

    private void openNotificationSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()));
        }
        startActivity(i);
    }
}
