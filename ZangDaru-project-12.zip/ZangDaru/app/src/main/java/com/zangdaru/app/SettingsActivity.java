package com.zangdaru.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    private void build() {
        final Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col);
        col.addView(Ui.topBar(this, "تنظیمات"), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        // ---- theme ----
        col.addView(Ui.text(this, "🎨  رنگ برنامه", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 20));
        LinearLayout tr = new LinearLayout(this);
        tr.setOrientation(LinearLayout.HORIZONTAL);
        tr.setBackground(Ui.box(this, p.soft, 20));
        tr.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6), Ui.dp(this, 8));
        for (int i = 0; i < Ui.PALS.length; i++) {
            final int k = i;
            boolean sel = (i == Store.theme(this));
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Ui.DOTS[i]);
            g.setStroke(Ui.dp(this, sel ? 4 : 1), sel ? 0xFF263238 : 0xFFB0BEC5);
            dot.setBackground(g);
            cell.addView(dot, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
            cell.addView(Ui.text(this, Ui.THEME_NAMES[i], 14, p.text, sel));
            cell.setOnClickListener(v -> { Store.setTheme(this, k); build(); });
            tr.addView(cell, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        }
        col.addView(tr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));

        // ---- text size ----
        col.addView(Ui.text(this, "🔤  اندازه‌ی نوشته‌ها", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 26));
        LinearLayout fr = new LinearLayout(this);
        fr.setOrientation(LinearLayout.HORIZONTAL);
        fr.setGravity(Gravity.CENTER_VERTICAL);
        TextView bigger = Ui.button(this, "A+  بزرگ‌تر", p.soft, p.text);
        bigger.setTextSize(16);
        bigger.setOnClickListener(v -> changeFont(0.1f));
        TextView smaller = Ui.button(this, "A−  کوچک‌تر", p.soft, p.text);
        smaller.setTextSize(16);
        smaller.setOnClickListener(v -> changeFont(-0.1f));
        TextView pct = Ui.text(this, Jalali.fa(String.valueOf(Math.round(Store.fontScale(this) * 100))) + "٪", 20, p.text, true);
        pct.setGravity(Gravity.CENTER);
        fr.addView(bigger, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        fr.addView(pct, new LinearLayout.LayoutParams(Ui.dp(this, 70), Ui.WRAP));
        fr.addView(smaller, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        col.addView(fr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        TextView sample = Ui.text(this, "نمونه‌ی نوشته: قرص فشار خون، ساعت ۰۸:۰۰", 18, p.text, false);
        sample.setBackground(Ui.box(this, p.soft, 16));
        sample.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        col.addView(sample, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));

        // ---- glass level ----
        col.addView(Ui.text(this, "🪟  شفافیت شیشه", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 26));
        int level = Store.glass(this);
        int[] presets = {15, 50, 100};
        String[] pn = {"شفاف", "شیشه‌ای", "مات"};
        LinearLayout gr = new LinearLayout(this);
        gr.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            final int val = presets[i];
            boolean on = level == val;
            TextView gb = Ui.button(this, pn[i], on ? p.primary : p.soft, on ? 0xFFFFFFFF : p.text);
            gb.setTextSize(16);
            gb.setOnClickListener(v -> { Store.setGlass(this, val); build(); });
            LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
            gl.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
            gr.addView(gb, gl);
        }
        col.addView(gr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        SeekBar glassBar = new SeekBar(this);
        glassBar.setMax(100);
        glassBar.setProgress(level);
        glassBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) { }

            @Override public void onStartTrackingTouch(SeekBar sb) { }

            @Override public void onStopTrackingTouch(SeekBar sb) {
                Store.setGlass(SettingsActivity.this, sb.getProgress());
                build();
            }
        });
        col.addView(glassBar, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
        LinearLayout ends = new LinearLayout(this);
        ends.setOrientation(LinearLayout.HORIZONTAL);
        TextView clearTv = Ui.text(this, "کاملاً شفاف", 14, p.text, false);
        clearTv.setGravity(Gravity.START);
        TextView matteTv = Ui.text(this, "کاملاً مات", 14, p.text, false);
        matteTv.setGravity(Gravity.END);
        ends.addView(clearTv, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        ends.addView(matteTv, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        col.addView(ends, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        // ---- wallpaper ----
        col.addView(Ui.text(this, "🖼  تصویر زمینه", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 26));
        String[] wn = {"💊🩺 ترکیبی", "💊 قرص و کپسول", "🩺❤️ پزشک و قلب", "▫️ ساده"};
        int cur = Store.bgStyle(this);
        for (int rowI = 0; rowI < 2; rowI++) {
            LinearLayout wr = new LinearLayout(this);
            wr.setOrientation(LinearLayout.HORIZONTAL);
            for (int colI = 0; colI < 2; colI++) {
                final int idx = rowI * 2 + colI;
                boolean on = cur == idx;
                TextView wb = Ui.button(this, wn[idx], on ? p.primary : p.soft, on ? 0xFFFFFFFF : p.text);
                wb.setTextSize(15);
                wb.setOnClickListener(v -> { Store.setBgStyle(this, idx); build(); });
                LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
                wl.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
                wr.addView(wb, wl);
            }
            col.addView(wr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        }

        // ---- guide / about ----
        TextView guide = Ui.button(this, "📖  راهنمای استفاده از برنامه", p.primary, 0xFFFFFFFF);
        guide.setOnClickListener(v -> startActivity(new Intent(this, GuideActivity.class)));
        col.addView(guide, Ui.lp(this, Ui.MATCH, Ui.WRAP, 24));
        TextView about = Ui.button(this, "ℹ️  درباره برنامه و سازنده", p.primary, 0xFFFFFFFF);
        about.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        col.addView(about, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));

        // ---- phone calendar ----
        col.addView(Ui.text(this, "📆  تقویم گوشی", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 28));
        boolean linked = CalSync.has(this);
        TextView cs = Ui.text(this, linked
                ? "متصل است ✅ داروها و وقت‌های پزشک در تقویم گوشی هم ثبت می‌شوند. برای وقت پزشک، هشدار تقویم گوشی هم دقیقاً در همان ساعت فعال می‌شود. رویدادهای تقویم گوشی هم در تقویم برنامه دیده می‌شوند."
                : "متصل نیست. برای ثبت در تقویم گوشی و دیدن رویدادهای آن، اجازه‌ی تقویم را بدهید.", 17, p.text, false);
        cs.setLineSpacing(0, 1.2f);
        col.addView(cs, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        if (!linked) {
            TextView link = Ui.button(this, "اتصال به تقویم گوشی", p.primary, 0xFFFFFFFF);
            link.setOnClickListener(v -> requestPermissions(new String[]{
                    "android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR"}, 2));
            col.addView(link, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        }

        // ---- reliability ----
        col.addView(Ui.text(this, "🔔  برای دقیق بودن زنگ", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 28));
        TextView n = Ui.button(this, "تنظیمات اعلان‌ها", p.soft, p.text);
        n.setOnClickListener(v -> openNotificationSettings());
        col.addView(n, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        TextView bat = Ui.button(this, "تنظیمات باتری (بدون محدودیت)", p.soft, p.text);
        bat.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this, "این صفحه در گوشی شما پیدا نشد", Toast.LENGTH_SHORT).show();
            }
        });
        col.addView(bat, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
        col.addView(Ui.text(this, "نسخه ۳٫۹", 14, p.text, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 24));
        Ui.apply(this, sv);
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rc, perms, res);
        new Thread(() -> CalSync.heal(this)).start();
        build();
    }

    private void changeFont(float delta) {
        float f = Math.round((Store.fontScale(this) + delta) * 10f) / 10f;
        f = Math.max(0.8f, Math.min(1.6f, f));
        Store.setFontScale(this, f);
        recreate();
    }

    private void openNotificationSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()));
        }
        startActivity(i);
    }
}
