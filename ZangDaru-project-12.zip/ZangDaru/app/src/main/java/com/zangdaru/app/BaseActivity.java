package com.zangdaru.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;

/** Applies the user's text-size choice (Settings) to every screen. */
public class BaseActivity extends Activity {
    private float applied = 1f;

    @Override
    protected void attachBaseContext(Context base) {
        float user = base.getSharedPreferences("zd", Context.MODE_PRIVATE).getFloat("fontScale", 1f);
        applied = user;
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.fontScale = cfg.fontScale * user;
        super.attachBaseContext(base.createConfigurationContext(cfg));
    }

    @Override
    protected void onResume() {
        super.onResume();
        float now = getSharedPreferences("zd", Context.MODE_PRIVATE).getFloat("fontScale", 1f);
        if (Math.abs(now - applied) > 0.001f) recreate();
    }
}
