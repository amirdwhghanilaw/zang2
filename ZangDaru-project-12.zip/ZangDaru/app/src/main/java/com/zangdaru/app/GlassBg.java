package com.zangdaru.app;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.Random;

/**
 * Modern backdrop: soft gradient, colourful glows and a pattern of thin line-art medical symbols
 * (capsule, tablet, cross, heart, pulse line, clock, drop, stethoscope, syringe, blister pack).
 * style: 0 = mixed medical symbols, 1 = pills, 2 = doctor and heart, 3 = plain.
 */
final class GlassBg extends Drawable {
    private static final int[][] SETS = {
        {0, 3, 7, 1, 4, 8, 2, 5, 9, 6},      // mixed
        {0, 1, 9, 0, 1, 6, 9, 1},            // pills
        {3, 4, 7, 2, 8, 3, 4, 7},            // doctor and heart
        {}                                   // plain
    };

    private final int c1, c2, c3, accent;
    private final int style;
    private final float density;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Shader base;
    private final Shader[] glow = new Shader[3];
    private final float[] gx = new float[3], gy = new float[3], gr = new float[3];
    private final Path[] unit = new Path[10];
    private final ArrayList<float[]> marks = new ArrayList<>();   // x, y, size, rotation, type, strength

    GlassBg(int c1, int c2, int c3, int accent, int style, float density) {
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.accent = accent;
        this.style = (style < 0 || style >= SETS.length) ? 0 : style;
        this.density = density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        buildUnits();
    }

    private void buildUnits() {
        Path p;
        p = new Path();   // capsule
        p.addRoundRect(new RectF(-40f, -18f, 40f, 18f), 18f, 18f, Path.Direction.CW);
        p.moveTo(0f, -18f);
        p.lineTo(0f, 18f);
        unit[0] = p;
        p = new Path();   // tablet
        p.addCircle(0f, 0f, 32f, Path.Direction.CW);
        p.moveTo(-32f, 0f);
        p.lineTo(32f, 0f);
        unit[1] = p;
        p = new Path();   // cross
        p.moveTo(-14f, -42f);
        p.lineTo(14f, -42f);
        p.lineTo(14f, -14f);
        p.lineTo(42f, -14f);
        p.lineTo(42f, 14f);
        p.lineTo(14f, 14f);
        p.lineTo(14f, 42f);
        p.lineTo(-14f, 42f);
        p.lineTo(-14f, 14f);
        p.lineTo(-42f, 14f);
        p.lineTo(-42f, -14f);
        p.lineTo(-14f, -14f);
        p.close();
        unit[2] = p;
        p = new Path();   // heart
        p.moveTo(0f, 34f);
        p.cubicTo(-70f, -8f, -34f, -52f, 0f, -18f);
        p.cubicTo(34f, -52f, 70f, -8f, 0f, 34f);
        p.close();
        unit[3] = p;
        p = new Path();   // pulse
        p.moveTo(-48f, 0f);
        p.lineTo(-24f, 0f);
        p.lineTo(-14f, -24f);
        p.lineTo(2f, 28f);
        p.lineTo(14f, -8f);
        p.lineTo(22f, 0f);
        p.lineTo(48f, 0f);
        unit[4] = p;
        p = new Path();   // clock
        p.addCircle(0f, 0f, 34f, Path.Direction.CW);
        p.moveTo(0f, 0f);
        p.lineTo(0f, -20f);
        p.moveTo(0f, 0f);
        p.lineTo(14f, 8f);
        unit[5] = p;
        p = new Path();   // drop
        p.moveTo(0f, -38f);
        p.cubicTo(8f, -22f, 30f, -6f, 30f, 14f);
        p.cubicTo(30f, 31f, 16f, 42f, 0f, 42f);
        p.cubicTo(-16f, 42f, -30f, 31f, -30f, 14f);
        p.cubicTo(-30f, -6f, -8f, -22f, 0f, -38f);
        p.close();
        unit[6] = p;
        p = new Path();   // stetho
        p.moveTo(-28f, -42f);
        p.lineTo(-28f, -4f);
        p.cubicTo(-28f, 24f, 28f, 24f, 28f, -4f);
        p.lineTo(28f, -42f);
        p.moveTo(0f, 17f);
        p.cubicTo(0f, 30f, 22f, 28f, 22f, 40f);
        p.addCircle(22f, 46f, 7f, Path.Direction.CW);
        unit[7] = p;
        p = new Path();   // syringe
        p.addRoundRect(new RectF(-11f, -28f, 11f, 20f), 5f, 5f, Path.Direction.CW);
        p.moveTo(-18f, -28f);
        p.lineTo(18f, -28f);
        p.moveTo(0f, -28f);
        p.lineTo(0f, -42f);
        p.moveTo(0f, 20f);
        p.lineTo(0f, 42f);
        p.moveTo(-11f, -8f);
        p.lineTo(-3f, -8f);
        p.moveTo(-11f, 2f);
        p.lineTo(-3f, 2f);
        unit[8] = p;
        p = new Path();   // blister
        p.addRoundRect(new RectF(-38f, -26f, 38f, 26f), 10f, 10f, Path.Direction.CW);
        p.addCircle(-20f, -9f, 8f, Path.Direction.CW);
        p.addCircle(0f, -9f, 8f, Path.Direction.CW);
        p.addCircle(20f, -9f, 8f, Path.Direction.CW);
        p.addCircle(-20f, 12f, 8f, Path.Direction.CW);
        p.addCircle(0f, 12f, 8f, Path.Direction.CW);
        p.addCircle(20f, 12f, 8f, Path.Direction.CW);
        unit[9] = p;
    }

    private static int clear(int c) { return c & 0x00FFFFFF; }

    private static int soft(int c, int alpha) { return (c & 0x00FFFFFF) | (alpha << 24); }

    @Override
    protected void onBoundsChange(Rect b) {
        float w = b.width(), h = b.height();
        if (w <= 0 || h <= 0) return;
        base = new LinearGradient(0, 0, w * 0.5f, h, c1, c2, Shader.TileMode.CLAMP);
        gx[0] = w * 0.88f; gy[0] = h * 0.10f; gr[0] = Math.max(w, h) * 0.48f;
        gx[1] = w * 0.05f; gy[1] = h * 0.50f; gr[1] = Math.max(w, h) * 0.52f;
        gx[2] = w * 0.80f; gy[2] = h * 0.92f; gr[2] = Math.max(w, h) * 0.55f;
        int[] centers = {c3, Ui.blend(c3, c1, 0.45f), c3};
        for (int i = 0; i < 3; i++) {
            glow[i] = new RadialGradient(gx[i], gy[i], gr[i], soft(centers[i], 0xCC),
                    clear(centers[i]), Shader.TileMode.CLAMP);
        }
        marks.clear();
        int[] set = SETS[style];
        if (set.length == 0) return;
        Random rnd = new Random(11);
        float cell = 112f * density;
        int rows = (int) Math.ceil(h / cell) + 1, cols = (int) Math.ceil(w / cell) + 1;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                float x = (c + (r % 2 == 0 ? 0.25f : 0.75f)) * cell + (rnd.nextFloat() - 0.5f) * cell * 0.35f;
                float y = (r + 0.5f) * cell + (rnd.nextFloat() - 0.5f) * cell * 0.30f;
                int type = set[(r * 3 + c * 4 + r / 2) % set.length];
                float size = (50 + rnd.nextFloat() * 22) * density;
                float rot = (rnd.nextFloat() - 0.5f) * 60f;
                float strength = 0.70f + rnd.nextFloat() * 0.30f;
                marks.add(new float[]{x, y, size, rot, type, strength});
            }
        }
    }

    @Override
    public void draw(Canvas cv) {
        Rect b = getBounds();
        if (base == null) onBoundsChange(b);
        if (base == null) return;
        paint.setShader(base);
        cv.drawRect(b, paint);
        for (int i = 0; i < 3; i++) {
            paint.setShader(glow[i]);
            cv.drawCircle(gx[i], gy[i], gr[i], paint);
        }
        paint.setShader(null);
        for (float[] m : marks) {
            int type = (int) m[4];
            float s = m[2] / 100f;
            int a = Math.round(0xC0 * m[5]);
            cv.save();
            cv.translate(m[0], m[1]);
            cv.rotate(m[3]);
            cv.scale(s, s);
            line.setStrokeWidth(2.6f * density / s);
            if (type == 3 || type == 6) {                        // heart and drop get a light tint inside
                fill.setColor(soft(accent, a / 6));
                cv.drawPath(unit[type], fill);
            }
            cv.save();                                           // white edge, shifted: gives an embossed glass look
            cv.translate(1.4f * density / s, 1.4f * density / s);
            line.setColor(soft(Color.WHITE, Math.round(a * 0.85f)));
            cv.drawPath(unit[type], line);
            cv.restore();
            line.setColor(soft(accent, Math.round(a * 0.46f)));  // the symbol itself, tinted with the theme colour
            cv.drawPath(unit[type], line);
            cv.restore();
        }
    }

    @Override public void setAlpha(int alpha) { }

    @Override public void setColorFilter(ColorFilter cf) { }

    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
