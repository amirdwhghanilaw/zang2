package com.zangdaru.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

final class Store {
    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("zd", Context.MODE_PRIVATE);
    }

    // ---------- medicines ----------
    static ArrayList<Med> all(Context c) {
        ArrayList<Med> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("meds", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(Med.from(a.getJSONObject(i)));
        } catch (JSONException e) { /* ignore */ }
        return l;
    }

    private static void write(Context c, ArrayList<Med> l) {
        JSONArray a = new JSONArray();
        try {
            for (Med m : l) a.put(m.toJson());
        } catch (JSONException e) { /* ignore */ }
        sp(c).edit().putString("meds", a.toString()).apply();
    }

    static Med get(Context c, int id) {
        for (Med m : all(c)) if (m.id == id) return m;
        return null;
    }

    static void save(Context c, Med m) {
        ArrayList<Med> l = all(c);
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id == m.id) { l.set(i, m); found = true; }
        }
        if (!found) l.add(m);
        write(c, l);
    }

    static void remove(Context c, int id) {
        ArrayList<Med> l = all(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id == id) l.remove(i);
        write(c, l);
    }

    static int nextId(Context c) {
        int id = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", id + 1).apply();
        return id;
    }

    // ---------- doctor appointments ----------
    static ArrayList<Appt> allAppts(Context c) {
        ArrayList<Appt> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("appts", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(Appt.from(a.getJSONObject(i)));
        } catch (JSONException e) { /* ignore */ }
        Collections.sort(l, new Comparator<Appt>() {
            @Override public int compare(Appt x, Appt y) { return Long.compare(x.millis(), y.millis()); }
        });
        return l;
    }

    private static void writeAppts(Context c, ArrayList<Appt> l) {
        JSONArray a = new JSONArray();
        try {
            for (Appt x : l) a.put(x.toJson());
        } catch (JSONException e) { /* ignore */ }
        sp(c).edit().putString("appts", a.toString()).apply();
    }

    static Appt getAppt(Context c, int id) {
        for (Appt x : allAppts(c)) if (x.id == id) return x;
        return null;
    }

    static void saveAppt(Context c, Appt a) {
        ArrayList<Appt> l = allAppts(c);
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id == a.id) { l.set(i, a); found = true; }
        }
        if (!found) l.add(a);
        writeAppts(c, l);
    }

    static void removeAppt(Context c, int id) {
        ArrayList<Appt> l = allAppts(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id == id) l.remove(i);
        writeAppts(c, l);
    }

    static int nextApptId(Context c) {
        int id = sp(c).getInt("nextApptId", 1);
        sp(c).edit().putInt("nextApptId", id + 1).apply();
        return id;
    }

    static boolean getBool(Context c, String k, boolean def) { return sp(c).getBoolean(k, def); }

    static void putBool(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }

    static long getLong(Context c, String k, long def) { return sp(c).getLong(k, def); }

    static void putLong(Context c, String k, long v) { sp(c).edit().putLong(k, v).apply(); }

    static void del(Context c, String k) { sp(c).edit().remove(k).apply(); }

    /** nid (medId*100+slot) of the medicine alarm that is ringing right now, or -1. */
    static int ringingNid(Context c) {
        long now = System.currentTimeMillis();
        int best = -1;
        long bestT = 0;
        for (Map.Entry<String, ?> e : sp(c).getAll().entrySet()) {
            String k = e.getKey();
            if (!k.startsWith("ring_") || !(e.getValue() instanceof Long)) continue;
            long t = (Long) e.getValue();
            if (now - t > 10 * 60 * 1000L) continue;      // the ring stops by itself after 10 minutes
            try {
                if (t > bestT) { bestT = t; best = Integer.parseInt(k.substring(5)); }
            } catch (NumberFormatException ex) { /* ignore */ }
        }
        return best;
    }

    static float fontScale(Context c) { return sp(c).getFloat("fontScale", 1f); }

    static void setFontScale(Context c, float v) { sp(c).edit().putFloat("fontScale", v).apply(); }

    /** 0 = clear glass ... 50 = frosted glass ... 100 = matte (opaque). */
    static int glass(Context c) { return sp(c).getInt("glass", 50); }

    static void setGlass(Context c, int v) { sp(c).edit().putInt("glass", v).apply(); }

    /** 0 = mixed medical symbols, 1 = pills, 2 = doctor and heart, 3 = plain. */
    static int bgStyle(Context c) { return sp(c).getInt("bgStyle", 0); }

    static void setBgStyle(Context c, int v) { sp(c).edit().putInt("bgStyle", v).apply(); }

    // ---------- theme ----------
    static int theme(Context c) {
        int t = sp(c).getInt("theme", 0);
        return (t < 0 || t >= Ui.PALS.length) ? 0 : t;
    }

    static void setTheme(Context c, int t) { sp(c).edit().putInt("theme", t).apply(); }
}
