package com.zangdaru.app;

import android.content.Context;
import java.util.Calendar;
import java.util.Locale;

/** What the live countdown on the home screen shows. */
final class Countdown {
    static final class Next {
        long target = -1;          // when the next alarm rings (ms), -1 = none
        boolean ringing;           // an alarm is ringing now and has not been stopped yet
        int medId = -1;
        String medName = "";
        String time = "";
    }

    /** Next ring of one medicine (regular times and a pending 10-minute snooze), or -1. */
    static long nextForMed(Context c, Med m, long now) {
        long best = -1;
        for (int i = 0; i < m.times.size(); i++) {
            long t = Alarms.nextTrigger(m, i, now);
            if (t > 0 && (best < 0 || t < best)) best = t;
            long sz = Store.getLong(c, "snz_" + m.id + "_" + i, 0);
            if (sz > now && (best < 0 || sz < best)) best = sz;
        }
        return best;
    }

    static Next compute(Context c) {
        Next n = new Next();
        long now = System.currentTimeMillis();
        int rn = Store.ringingNid(c);
        if (rn >= 0) {
            Med m = Store.get(c, rn / 100);
            if (m != null) {
                n.ringing = true;
                n.medId = m.id;
                n.medName = m.name;
                n.target = now;
                int idx = rn % 100;
                if (idx < m.times.size()) n.time = m.times.get(idx);
                return n;
            }
            Store.del(c, "ring_" + rn);
        }
        for (Med m : Store.all(c)) {
            long t = nextForMed(c, m, now);
            if (t > 0 && (n.target < 0 || t < n.target)) {
                n.target = t;
                n.medId = m.id;
                n.medName = m.name;
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(t);
                n.time = Ui.hm(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
            }
        }
        return n;
    }

    /** hours:minutes:seconds (hours can pass 24, no days / weeks / months). */
    static String hms(long ms) {
        long total = Math.max(0, (ms + 999) / 1000);
        return Jalali.fa(String.format(Locale.US, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60));
    }
}
