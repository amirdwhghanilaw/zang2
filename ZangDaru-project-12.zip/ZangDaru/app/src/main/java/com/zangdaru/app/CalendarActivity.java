package com.zangdaru.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

/** One-year Persian calendar. Modes: view / pick several days / pick one day. */
public class CalendarActivity extends BaseActivity {
    static final int MODE_VIEW = 0, MODE_MULTI = 1, MODE_SINGLE = 2;

    private Ui.Pal p;
    private int mode, jy, todayKey;
    private final HashSet<Integer> selected = new HashSet<>();
    private final HashMap<Integer, ArrayList<String>> medMap = new HashMap<>();
    private final HashMap<Integer, ArrayList<String>> apptMap = new HashMap<>();
    private final HashMap<Integer, ArrayList<String>> phoneMap = new HashMap<>();
    private final HashMap<Integer, TextView> cells = new HashMap<>();
    private ScrollView sv;
    private LinearLayout[] monthCards = new LinearLayout[12];
    private TextView confirmBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Ui.pal(this);
        mode = getIntent().getIntExtra("mode", MODE_VIEW);
        int[] sel = getIntent().getIntArrayExtra("dates");
        if (sel != null) for (int k : sel) selected.add(k);
        todayKey = Jalali.todayKey();
        jy = Jalali.todayJ()[0];
        if (mode == MODE_SINGLE && !selected.isEmpty()) {
            int[] g = Jalali.unkey(Collections.min(selected));
            jy = Jalali.g2j(g[0], g[1], g[2])[0];
        }
        loadEvents();
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mode == MODE_VIEW) { loadEvents(); build(); }
    }

    private void addTo(HashMap<Integer, ArrayList<String>> map, int key, String s) {
        ArrayList<String> l = map.get(key);
        if (l == null) { l = new ArrayList<>(); map.put(key, l); }
        l.add(s);
    }

    private void loadEvents() {
        medMap.clear();
        apptMap.clear();
        for (Med m : Store.all(this)) {
            StringBuilder t = new StringBuilder();
            for (int i = 0; i < m.times.size(); i++) {
                if (i > 0) t.append("، ");
                t.append(Jalali.fa(m.times.get(i)));
            }
            String label = m.name + " (" + t + ")";
            for (int k : m.dayKeys()) addTo(medMap, k, label);
        }
        for (Appt a : Store.allAppts(this)) {
            addTo(apptMap, a.dateKey, a.doctor + " - ساعت " + a.timeText());
        }
        phoneMap.clear();
        phoneMap.putAll(CalSync.yearEvents(this, jy));
    }

    private void build() {
        cells.clear();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);
        int pad = Ui.dp(this, 12);
        String title = mode == MODE_VIEW ? "تقویم شمسی" : mode == MODE_MULTI ? "انتخاب روزهای مصرف" : "انتخاب روز مراجعه";
        LinearLayout.LayoutParams bp = Ui.lp(this, Ui.MATCH, Ui.WRAP, 0);
        bp.setMargins(pad, pad, pad, 0);
        root.addView(Ui.topBar(this, title), bp);

        // year navigation
        LinearLayout yr = new LinearLayout(this);
        yr.setOrientation(LinearLayout.HORIZONTAL);
        yr.setGravity(Gravity.CENTER_VERTICAL);
        TextView prev = Ui.button(this, "سال قبل", p.soft, p.text);
        prev.setTextSize(15);
        prev.setOnClickListener(v -> { jy--; loadEvents(); build(); });
        TextView next = Ui.button(this, "سال بعد", p.soft, p.text);
        next.setTextSize(15);
        next.setOnClickListener(v -> { jy++; loadEvents(); build(); });
        TextView ytv = Ui.text(this, Jalali.fa(String.valueOf(jy)), 28, p.primary, true);
        ytv.setGravity(Gravity.CENTER);
        yr.addView(prev, new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
        yr.addView(ytv, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        yr.addView(next, new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
        LinearLayout.LayoutParams yp = Ui.lp(this, Ui.MATCH, Ui.WRAP, 8);
        yp.setMargins(pad, Ui.dp(this, 8), pad, 0);
        root.addView(yr, yp);

        String legend = mode == MODE_VIEW
                ? "🟢 مصرف دارو    🟠 پزشک    🔵 تقویم گوشی    ▢ امروز"
                : mode == MODE_MULTI ? "روزها را لمس کنید، یا «همه‌ی روزها»ی هر ماه را بزنید" : "روی روز مراجعه بزنید";
        TextView lg = Ui.text(this, legend, 14, p.text, false);
        lg.setGravity(Gravity.CENTER);
        root.addView(lg, Ui.lp(this, Ui.MATCH, Ui.WRAP, 4));

        sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);
        for (int jm = 1; jm <= 12; jm++) {
            monthCards[jm - 1] = monthCard(jm);
            col.addView(monthCards[jm - 1], Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
        }
        sv.addView(col);
        root.addView(sv, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));

        if (mode == MODE_MULTI) {
            LinearLayout bar = new LinearLayout(this);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            bar.setPadding(pad, pad, pad, pad);
            bar.setBackground(Ui.box(this, p.soft, 0));
            confirmBtn = Ui.button(this, "", 0xFF2E9E5B, Color.WHITE);
            confirmBtn.setOnClickListener(v -> confirm());
            TextView clear = Ui.button(this, "پاک کردن", 0xFFEF9A9A, 0xFF5D1010);
            clear.setTextSize(16);
            clear.setOnClickListener(v -> {
                selected.clear();
                for (java.util.Map.Entry<Integer, TextView> e : cells.entrySet()) style(e.getValue(), e.getKey());
                updateConfirm();
            });
            bar.addView(confirmBtn, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
            cl.setMarginStart(Ui.dp(this, 10));
            bar.addView(clear, cl);
            root.addView(bar, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
            updateConfirm();
        }

        Ui.apply(this, root);

        final int[] tj = Jalali.todayJ();
        if (jy == tj[0]) {
            sv.post(() -> sv.scrollTo(0, monthCards[tj[1] - 1].getTop()));
        }
    }

    private LinearLayout monthCard(int jm) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.box(this, Color.WHITE, 18));
        int pd = Ui.dp(this, 8);
        card.setPadding(pd, pd, pd, pd);

        LinearLayout hrow = new LinearLayout(this);
        hrow.setOrientation(LinearLayout.HORIZONTAL);
        hrow.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = Ui.text(this, Jalali.MONTHS[jm - 1] + " " + Jalali.fa(String.valueOf(jy)), 20, p.primary, true);
        t.setGravity(Gravity.CENTER);
        hrow.addView(t, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        if (mode == MODE_MULTI) {
            TextView all = Ui.button(this, "همه‌ی روزها", p.soft, p.text);
            all.setTextSize(13);
            all.setMinHeight(0);
            all.setMinimumHeight(0);
            all.setPadding(Ui.dp(this, 10), Ui.dp(this, 3), Ui.dp(this, 10), Ui.dp(this, 3) + Ui.dp(this, 6));
            all.setOnClickListener(v -> toggleMonth(jm));
            hrow.addView(all, new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
        }
        card.addView(hrow, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        LinearLayout hdr = new LinearLayout(this);
        hdr.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            TextView h = Ui.text(this, Jalali.WD_SHORT[i], 14, i == 6 ? 0xFFD32F2F : p.text, true);
            h.setGravity(Gravity.CENTER);
            hdr.addView(h, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        }
        card.addView(hdr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));

        int len = Jalali.monthLength(jy, jm);
        int[] g1 = Jalali.j2g(jy, jm, 1);
        int start = Jalali.weekdayIndexOfKey(Jalali.key(g1[0], g1[1], g1[2]));
        int day = 1;
        for (int r = 0; r < 6 && day <= len; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 7; c++) {
                int pos = r * 7 + c;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f);
                lp.setMargins(2, 2, 2, 2);
                if (pos < start || day > len) {
                    row.addView(new View(this), lp);
                } else {
                    int[] g = Jalali.j2g(jy, jm, day);
                    final int key = Jalali.key(g[0], g[1], g[2]);
                    TextView cell = Ui.text(this, Jalali.fa(String.valueOf(day)), 18, p.text, false);
                    cell.setGravity(Gravity.CENTER);
                    cell.setOnClickListener(v -> onDay(key));
                    cells.put(key, cell);
                    style(cell, key);
                    row.addView(cell, lp);
                    day++;
                }
            }
            card.addView(row, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        }
        return card;
    }

    private void style(TextView t, int key) {
        boolean sel = selected.contains(key);
        boolean past = key < todayKey;
        boolean med = medMap.containsKey(key), ap = apptMap.containsKey(key);
        int bg = 0;
        boolean ph = phoneMap.containsKey(key);
        if (med && ap) bg = 0xFFFFF59D; else if (med) bg = 0xFFC8E6C9; else if (ap) bg = 0xFFFFE0B2; else if (ph) bg = 0xFFBBDEFB;
        int fg = Jalali.weekdayIndexOfKey(key) == 6 ? 0xFFD32F2F : p.text;
        if (mode != MODE_VIEW && past) fg = 0xFFBDBDBD;
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(Ui.dp(this, 10));
        if (sel) { g.setColor(Ui.withAlpha(p.primary, 0xE0)); fg = Color.WHITE; }
        else g.setColor(bg != 0 ? Ui.withAlpha(bg, 0xB4) : Color.TRANSPARENT);
        if (key == todayKey) g.setStroke(Ui.dp(this, 3), p.primary);
        t.setBackground(g);
        t.setTextColor(fg);
        t.setTypeface(sel || key == todayKey ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
    }

    private void onDay(int key) {
        if (mode == MODE_VIEW) { showDay(key); return; }
        if (key < todayKey) { Toast.makeText(this, "این روز گذشته است", Toast.LENGTH_SHORT).show(); return; }
        if (mode == MODE_SINGLE) {
            Intent r = new Intent();
            r.putExtra("dates", new int[]{key});
            setResult(RESULT_OK, r);
            finish();
            return;
        }
        if (!selected.remove(key)) selected.add(key);
        style(cells.get(key), key);
        updateConfirm();
    }

    /** Selects every remaining day of one month, or clears them if they are all selected already. */
    private void toggleMonth(int jm) {
        ArrayList<Integer> keys = new ArrayList<>();
        int len = Jalali.monthLength(jy, jm);
        for (int d = 1; d <= len; d++) {
            int[] g = Jalali.j2g(jy, jm, d);
            int k = Jalali.key(g[0], g[1], g[2]);
            if (k >= todayKey) keys.add(k);
        }
        if (keys.isEmpty()) {
            Toast.makeText(this, "روزهای این ماه گذشته است", Toast.LENGTH_SHORT).show();
            return;
        }
        if (selected.containsAll(keys)) selected.removeAll(keys); else selected.addAll(keys);
        for (int k : keys) {
            TextView cell = cells.get(k);
            if (cell != null) style(cell, k);
        }
        updateConfirm();
    }

    private void updateConfirm() {
        if (confirmBtn != null) confirmBtn.setText("✅ تأیید (" + Jalali.fa(String.valueOf(selected.size())) + " روز)");
    }

    private void confirm() {
        ArrayList<Integer> l = new ArrayList<>(selected);
        Collections.sort(l);
        int[] arr = new int[l.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = l.get(i);
        Intent r = new Intent();
        r.putExtra("dates", arr);
        setResult(RESULT_OK, r);
        finish();
    }

    private void showDay(final int key) {
        ArrayList<String> ms = medMap.get(key), as = apptMap.get(key);
        StringBuilder sb = new StringBuilder();
        if (ms != null) {
            sb.append("💊 داروها:\n");
            for (String s : ms) sb.append("• ").append(s).append("\n");
        }
        if (as != null) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("🩺 مراجعه به پزشک:\n");
            for (String s : as) sb.append("• ").append(s).append("\n");
        }
        ArrayList<String> ps = phoneMap.get(key);
        if (ps != null) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("📱 تقویم گوشی:\n");
            for (String s : ps) sb.append("• ").append(s).append("\n");
        }
        if (sb.length() == 0) sb.append("برای این روز موردی ثبت نشده است.");
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(this)
                .setTitle(Jalali.fmtFull(key))
                .setMessage(sb.toString().trim())
                .setNegativeButton("بستن", null);
        if (key >= todayKey) {
            b.setPositiveButton("ثبت وقت پزشک", (d, w) -> {
                Intent i = new Intent(this, ApptEditActivity.class);
                i.putExtra("date", key);
                startActivity(i);
            });
        }
        Ui.show(b);
    }
}
