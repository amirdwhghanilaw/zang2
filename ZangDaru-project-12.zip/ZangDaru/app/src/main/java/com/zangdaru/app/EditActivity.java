package com.zangdaru.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;

public class EditActivity extends BaseActivity {
    private static final int REQ_GAL = 1, REQ_CAM = 2, REQ_CAL = 3;
    private Ui.Pal p;
    private Med med;
    private String photo = "", origPhoto = "";
    private final ArrayList<String> times = new ArrayList<>();
    private final ArrayList<Integer> dates = new ArrayList<>();
    private int choice = 7;            // 7 / 14 / 30 days, or -1 = days chosen from the calendar
    private boolean saved = false;
    private ImageView img;
    private TextView emptyPhoto, datesSummary;
    private EditText name, note;
    private LinearLayout timesBox, datesBox;
    private Uri camUri;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Ui.pal(this);
        int id = getIntent().getIntExtra("id", -1);
        med = id >= 0 ? Store.get(this, id) : null;
        if (med != null) {
            photo = origPhoto = med.photo == null ? "" : med.photo;
            times.addAll(med.times);
            if (med.byDates()) dates.addAll(med.dates);
            else {
                int today = Jalali.todayKey();
                for (int k : med.dayKeys()) if (k >= today) dates.add(k);   // older "every day for N days" medicines
            }
        }
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col);

        col.addView(Ui.topBar(this, med == null ? "افزودن داروی جدید" : "ویرایش دارو"), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        // ---- photo ----
        col.addView(Ui.text(this, "عکس دارو", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 16));
        FrameLayout pf = new FrameLayout(this);
        pf.setBackground(Ui.box(this, p.soft, 20));
        emptyPhoto = Ui.text(this, "💊\nعکسی انتخاب نشده", 18, p.text, false);
        emptyPhoto.setGravity(Gravity.CENTER);
        pf.addView(emptyPhoto, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pf.addView(img, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        col.addView(pf, Ui.lp(this, Ui.MATCH, Ui.dp(this, 220), 6));
        LinearLayout pr = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        TextView cam = Ui.button(this, "📷 گرفتن عکس", p.primary, Color.WHITE);
        cam.setTextSize(17);
        cam.setOnClickListener(v -> takePhoto());
        TextView gal = Ui.button(this, "🖼 از گالری", p.primary, Color.WHITE);
        gal.setTextSize(17);
        gal.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            i.setType("image/*");
            startActivityForResult(i, REQ_GAL);
        });
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        l1.setMarginEnd(Ui.dp(this, 6));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        l2.setMarginStart(Ui.dp(this, 6));
        pr.addView(cam, l1);
        pr.addView(gal, l2);
        col.addView(pr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        refreshPhoto();

        // ---- name / note ----
        col.addView(Ui.text(this, "نام دارو", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 18));
        name = field("مثلاً: قرص فشار خون", med == null ? "" : med.name);
        col.addView(name, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));
        col.addView(Ui.text(this, "توضیح (اختیاری)", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 14));
        note = field("مثلاً: بعد از غذا، یک عدد", med == null ? "" : med.note);
        col.addView(note, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));

        // ---- times ----
        col.addView(Ui.text(this, "ساعت‌های مصرف در روز", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 18));
        timesBox = new LinearLayout(this);
        timesBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(timesBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));
        TextView addT = Ui.button(this, "➕ افزودن ساعت", p.soft, p.text);
        addT.setOnClickListener(v -> {
            if (times.size() >= 24) { toast("حداکثر ۲۴ ساعت در روز"); return; }
            TimeDialog.show(this, 8, 0, (hh, mm) -> {
                String t = Ui.hm(hh, mm);
                if (!times.contains(t)) times.add(t);
                renderTimes();
            });
        });
        col.addView(addT, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));
        TextView rep = Ui.button(this, "🔁  تکرار هر چند ساعت (۱ تا ۲۴)", p.soft, p.text);
        rep.setOnClickListener(v -> TimeDialog.showRepeat(this, list -> {
            times.clear();
            times.addAll(list);
            renderTimes();
        }));
        col.addView(rep, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        renderTimes();

        // ---- days (from the calendar only) ----
        col.addView(Ui.text(this, "روزهای مصرف (از تقویم شمسی)", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 18));
        col.addView(Ui.text(this, "دارو در همین روزها و در ساعت‌های بالا زنگ می‌خورد.", 15, p.text, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 4));

        datesBox = new LinearLayout(this);
        datesBox.setOrientation(LinearLayout.VERTICAL);
        datesBox.setBackground(Ui.box(this, p.soft, 20));
        datesBox.setPadding(pad, pad, pad, pad);
        datesSummary = Ui.text(this, "", 17, p.text, false);
        datesSummary.setLineSpacing(0, 1.2f);
        datesBox.addView(datesSummary);
        TextView pick = Ui.button(this, "📅  انتخاب روزها از تقویم", p.primary, Color.WHITE);
        pick.setTextSize(18);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(this, CalendarActivity.class);
            i.putExtra("mode", CalendarActivity.MODE_MULTI);
            int[] arr = new int[dates.size()];
            for (int k = 0; k < arr.length; k++) arr[k] = dates.get(k);
            i.putExtra("dates", arr);
            startActivityForResult(i, REQ_CAL);
        });
        datesBox.addView(pick, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
        TextView weekly = Ui.button(this, "🔁  هر هفته در یک روز مشخص", p.primary, Color.WHITE);
        weekly.setTextSize(18);
        weekly.setOnClickListener(v -> weeklyFill());
        datesBox.addView(weekly, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        col.addView(datesBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        renderDates();

        // ---- actions ----
        TextView save = Ui.button(this, "💾  ذخیره", 0xFF2E9E5B, Color.WHITE);
        save.setTextSize(22);
        save.setOnClickListener(v -> save());
        col.addView(save, Ui.lp(this, Ui.MATCH, Ui.dp(this, 66), 24));

        if (med != null) {
            TextView test = Ui.button(this, "🔔 آزمایش زنگ (۱۰ ثانیه دیگر)", p.soft, p.text);
            test.setOnClickListener(v -> {
                Alarms.setAt(this, System.currentTimeMillis() + 10000, Alarms.slotPi(this, med.id, 0, true));
                toast("۱۰ ثانیه‌ی دیگر زنگ می‌خورد");
            });
            col.addView(test, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
            TextView del = Ui.button(this, "🗑  حذف دارو", 0xFFD32F2F, Color.WHITE);
            del.setOnClickListener(v -> confirmDelete());
            col.addView(del, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        }
        Ui.apply(this, sv);
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextSize(22);
        e.setTextColor(p.text);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setSingleLine(true);
        e.setBackground(Ui.box(this, Color.WHITE, 14));
        int q = Ui.dp(this, 14);
        e.setPadding(q, q, q, q);
        return e;
    }

    private RadioButton radio(String s) {
        RadioButton r = new RadioButton(this);
        r.setId(View.generateViewId());
        r.setText(s);
        r.setTextSize(19);
        r.setTextColor(p.text);
        r.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10));
        return r;
    }

    private void renderTimes() {
        timesBox.removeAllViews();
        Collections.sort(times);
        for (final String t : times) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(Ui.box(this, p.soft, 14));
            row.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
            TextView tv = Ui.text(this, "🕐  " + Jalali.fa(t), 26, p.text, true);
            row.addView(tv, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            TextView rm = Ui.button(this, "حذف", 0xFFEF9A9A, 0xFF5D1010);
            rm.setTextSize(16);
            rm.setOnClickListener(v -> { times.remove(t); renderTimes(); });
            row.addView(rm, new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
            timesBox.addView(row, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));
        }
    }

    private void renderDates() {
        Collections.sort(dates);
        if (dates.isEmpty()) {
            datesSummary.setText("هنوز روزی انتخاب نشده است.");
            return;
        }
        StringBuilder sb = new StringBuilder("روزهای انتخاب‌شده (" + Jalali.fa(String.valueOf(dates.size())) + " روز):");
        int shown = Math.min(dates.size(), 8);
        for (int i = 0; i < shown; i++) sb.append("\n• ").append(Jalali.fmtFull(dates.get(i)));
        if (dates.size() > shown) sb.append("\n… و ").append(Jalali.fa(String.valueOf(dates.size() - shown))).append(" روز دیگر");
        datesSummary.setText(sb.toString());
    }

    private void weeklyFill() {
        Ui.show(new AlertDialog.Builder(this)
                .setTitle("در کدام روز هفته؟")
                .setItems(Jalali.WEEKDAYS, (d1, weekday) -> {
                    final String[] labels = {"۴ هفته", "۸ هفته", "۱۲ هفته", "یک سال (۵۲ هفته)"};
                    final int[] counts = {4, 8, 12, 52};
                    Ui.show(new AlertDialog.Builder(this)
                            .setTitle("به مدت چند هفته؟")
                            .setItems(labels, (d2, which) -> fillWeekly(weekday, counts[which])));
                }));
    }

    private void fillWeekly(int weekdayIdx, int weeks) {
        int today = Jalali.todayKey();
        int delta = (weekdayIdx - Jalali.weekdayIndexOfKey(today) + 7) % 7;
        int first = Jalali.addDays(today, delta);
        dates.clear();
        for (int i = 0; i < weeks; i++) dates.add(Jalali.addDays(first, 7 * i));
        renderDates();
    }

    private void refreshPhoto() {
        Bitmap b = photo.isEmpty() ? null : Ui.decodeFile(photo, 900);
        img.setImageBitmap(b);
        emptyPhoto.setVisibility(b == null ? View.VISIBLE : View.GONE);
    }

    private void takePhoto() {
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.TITLE, "zang-daru");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
            startActivityForResult(i, REQ_CAM);
        } catch (Exception e) {
            toast("دوربین باز نشد؛ لطفاً از گالری انتخاب کنید");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (res != RESULT_OK) return;
        if (req == REQ_CAL) {
            if (d != null) {
                int[] arr = d.getIntArrayExtra("dates");
                dates.clear();
                if (arr != null) for (int k : arr) dates.add(k);
                renderDates();
            }
            return;
        }
        Uri u = null;
        if (req == REQ_GAL && d != null) u = d.getData();
        else if (req == REQ_CAM) u = camUri;
        if (u == null) return;
        Bitmap b = Ui.decodeUri(this, u, 1024);
        if (req == REQ_CAM) {
            try { getContentResolver().delete(u, null, null); } catch (Exception e) { /* ignore */ }
        }
        if (b == null) { toast("عکس خوانده نشد"); return; }
        File f = new File(getFilesDir(), "photo_" + System.currentTimeMillis() + ".jpg");
        try (FileOutputStream o = new FileOutputStream(f)) {
            b.compress(Bitmap.CompressFormat.JPEG, 88, o);
        } catch (Exception e) {
            toast("ذخیره‌ی عکس انجام نشد");
            return;
        }
        if (!photo.isEmpty() && !photo.equals(origPhoto)) new File(photo).delete();
        photo = f.getAbsolutePath();
        refreshPhoto();
    }

    private void save() {
        String n = name.getText().toString().trim();
        if (n.isEmpty()) { toast("لطفاً نام دارو را بنویسید"); return; }
        if (times.isEmpty()) { toast("حداقل یک ساعت مصرف اضافه کنید"); return; }
        if (dates.isEmpty()) { toast("روزهای مصرف را از تقویم انتخاب کنید"); return; }
        Med m = med != null ? med : new Med();
        if (med == null) m.id = Store.nextId(this);
        else Alarms.cancelMed(this, m.id);
        m.name = n;
        m.note = note.getText().toString().trim();
        m.photo = photo;
        m.times = new ArrayList<>(times);
        Collections.sort(dates);
        m.dates = new ArrayList<>(dates);
        m.days = 7;
        m.startMs = Med.todayStart();
        Store.save(this, m);
        Alarms.scheduleMed(this, m);
        final android.content.Context app = getApplicationContext();
        final Med fm = m;
        new Thread(() -> { CalSync.syncMed(app, fm); Store.save(app, fm); }).start();
        if (!origPhoto.isEmpty() && !origPhoto.equals(photo)) new File(origPhoto).delete();
        saved = true;
        toast("ذخیره شد ✅");
        finish();
    }

    private void confirmDelete() {
        Ui.show(new AlertDialog.Builder(this)
                .setMessage("این دارو حذف شود؟")
                .setPositiveButton("بله، حذف شود", (dlg, w) -> {
                    Alarms.cancelMed(this, med.id);
                    CalSync.deleteMany(this, med.evIds);
                    Store.remove(this, med.id);
                    if (!origPhoto.isEmpty()) new File(origPhoto).delete();
                    if (!photo.isEmpty() && !photo.equals(origPhoto)) new File(photo).delete();
                    saved = true;
                    finish();
                })
                .setNegativeButton("نه", null));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // discard a newly picked photo if the user left without saving
        if (isFinishing() && !saved && !photo.isEmpty() && !photo.equals(origPhoto)) new File(photo).delete();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
