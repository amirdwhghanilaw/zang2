# Generates launcher icons: a clock whose numbers are replaced by pills.
from PIL import Image, ImageDraw
import math, os
RES = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'res')
PINK, MINT, BLUE, GREEN = (240,98,146), (72,196,160), (66,150,230), (76,175,80)
WHITE = (255,255,255)

def darker(c, f=0.72): return tuple(int(v*f) for v in c)

def pill(kind, L, W, c1, c2, S=4):
    pad = 6*S; w = int(L*S)+2*pad; h = int(W*S)+2*pad
    mask = Image.new('L', (w,h), 0); md = ImageDraw.Draw(mask)
    box = (pad, pad, w-pad, h-pad)
    rad = int(W*S/2) if kind == 'cap' else int(W*S/2.4)
    if kind == 'tab': md.ellipse(box, fill=255)
    else: md.rounded_rectangle(box, radius=rad, fill=255)
    lay = Image.new('RGBA', (w,h), c2+(255,)); d = ImageDraw.Draw(lay)
    if kind == 'cap': d.rectangle((0,0,w//2,h), fill=c1+(255,))
    else: lay.paste(Image.new('RGBA',(w,h), c1+(255,)))
    if kind != 'cap': d.line((w//2, pad+W*S*0.18, w//2, h-pad-W*S*0.18), fill=darker(c1)+(255,), width=max(2,int(W*S*0.07)))
    hl = Image.new('RGBA', (w,h), (0,0,0,0)); hd = ImageDraw.Draw(hl)
    hd.rounded_rectangle((pad+L*S*0.12, pad+W*S*0.14, w-pad-L*S*0.12, pad+W*S*0.34), radius=int(W*S*0.1), fill=(255,255,255,110))
    lay = Image.alpha_composite(lay, hl)
    ol = Image.new('RGBA', (w,h), (0,0,0,0)); od = ImageDraw.Draw(ol)
    if kind == 'tab': od.ellipse(box, outline=darker(c1,0.6)+(255,), width=3*S)
    else: od.rounded_rectangle(box, radius=rad, outline=darker(c1,0.6)+(255,), width=3*S)
    lay = Image.alpha_composite(lay, ol)
    lay.putalpha(Image.composite(lay.getchannel('A'), Image.new('L',(w,h),0), mask))
    return lay

SPEC = [('cap',PINK,WHITE),('tab',MINT,None),('cap',BLUE,WHITE),('oval',GREEN,None),
        ('tab',PINK,None),('cap',MINT,WHITE),('oval',BLUE,None),('cap',GREEN,WHITE),
        ('tab',BLUE,None),('cap',PINK,MINT),('oval',PINK,None),('tab',GREEN,None)]

def clock(D):
    S = 2; N = D*S
    im = Image.new('RGBA', (N,N), (0,0,0,0)); d = ImageDraw.Draw(im)
    d.ellipse((0,0,N-1,N-1), fill=PINK+(255,))
    rim = int(N*0.045)
    d.ellipse((rim,rim,N-1-rim,N-1-rim), fill=WHITE+(255,))
    r2 = int(N*0.06)
    d.ellipse((r2,r2,N-1-r2,N-1-r2), outline=MINT+(255,), width=max(2,int(N*0.008)))
    cx = cy = N/2; R = N*0.332
    for k,(kind,c1,c2) in enumerate(SPEC):
        a = math.radians(k*30)
        if kind == 'cap': L,W = N*0.125, N*0.064
        elif kind == 'oval': L,W = N*0.105, N*0.066
        else: L,W = N*0.075, N*0.075
        lay = pill(kind, L, W, c1, c2 or c1, S=2)
        lay = lay.rotate(90 - k*30, expand=True, resample=Image.BICUBIC)
        px = cx + R*math.sin(a) - lay.width/2; py = cy - R*math.cos(a) - lay.height/2
        im.alpha_composite(lay, (int(px), int(py)))
    hand = (55,71,79,255)
    def line(deg, ln, wd):
        a = math.radians(deg); ex = cx + ln*math.sin(a); ey = cy - ln*math.cos(a)
        d.line((cx,cy,ex,ey), fill=hand, width=int(wd))
        d.ellipse((ex-wd/2,ey-wd/2,ex+wd/2,ey+wd/2), fill=hand)
    line(305, N*0.15, N*0.032); line(60, N*0.23, N*0.024)
    cr = N*0.03
    d.ellipse((cx-cr,cy-cr,cx+cr,cy+cr), fill=PINK+(255,))
    d.ellipse((cx-cr/2.4,cy-cr/2.4,cx+cr/2.4,cy+cr/2.4), fill=WHITE+(255,))
    return im.resize((D,D), Image.LANCZOS)

def grad_bg(S):
    g = Image.linear_gradient('L').resize((S,S))
    a = Image.new('RGB',(S,S),(191,233,216)); b = Image.new('RGB',(S,S),(255,196,218))
    return Image.composite(b, a, g).convert('RGBA')

def legacy(S, round_=False):
    big = 1024
    bg = grad_bg(big); m = Image.new('L',(big,big),0); md = ImageDraw.Draw(m)
    if round_: md.ellipse((0,0,big-1,big-1), fill=255)
    else: md.rounded_rectangle((0,0,big-1,big-1), radius=int(big*0.22), fill=255)
    bg.putalpha(m)
    c = clock(int(big*(0.80 if round_ else 0.86)))
    bg.alpha_composite(c, ((big-c.width)//2, (big-c.height)//2))
    return bg.resize((S,S), Image.LANCZOS)

def foreground(S):
    big = S*4
    im = Image.new('RGBA',(big,big),(0,0,0,0))
    c = clock(int(big*0.60)); im.alpha_composite(c, ((big-c.width)//2,(big-c.height)//2))
    return im.resize((S,S), Image.LANCZOS)

dens = {'mdpi':1,'hdpi':1.5,'xhdpi':2,'xxhdpi':3,'xxxhdpi':4}
for n,f in dens.items():
    for sub,fn in (('mipmap','ic_launcher'),):
        os.makedirs(f'{RES}/mipmap-{n}', exist_ok=True)
        legacy(int(48*f)).save(f'{RES}/mipmap-{n}/ic_launcher.png')
        legacy(int(48*f), True).save(f'{RES}/mipmap-{n}/ic_launcher_round.png')
    os.makedirs(f'{RES}/drawable-{n}', exist_ok=True)
    foreground(int(108*f)).save(f'{RES}/drawable-{n}/ic_launcher_foreground.png')
legacy(512).save(os.path.join(os.path.dirname(__file__), '..', 'play-store-icon-512.png'))
print('ok')
